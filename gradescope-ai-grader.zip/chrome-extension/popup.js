/**
 * Gradescope AI Grader - Popup Script
 * Handles configuration UI
 */

// Load saved configuration
document.addEventListener('DOMContentLoaded', async () => {
  const config = await chrome.storage.sync.get(['apiKey', 'rubricText', 'answerKeyImages']);

  if (config.apiKey) {
    document.getElementById('apiKey').value = config.apiKey;
    updateApiKeyStatus(true);
  }

  if (config.rubricText) {
    document.getElementById('rubricText').value = config.rubricText;
  }

  if (config.answerKeyImages) {
    displayAnswerKeyList(config.answerKeyImages);
  }
});

// Save button handler
document.getElementById('saveButton').addEventListener('click', async () => {
  const apiKey = document.getElementById('apiKey').value.trim();
  const rubricText = document.getElementById('rubricText').value.trim();

  if (!apiKey) {
    showStatus('Please enter an API key', 'error');
    return;
  }

  // Validate API key format
  if (!apiKey.startsWith('sk-')) {
    showStatus('Invalid API key format', 'error');
    return;
  }

  // Get answer key images
  const answerKeyImages = await processAnswerKeyFiles();

  // Save to storage
  await chrome.storage.sync.set({
    apiKey,
    rubricText,
    answerKeyImages
  });

  updateApiKeyStatus(true);
  showStatus('Configuration saved successfully!', 'success');

  // Auto-close popup after 2 seconds
  setTimeout(() => {
    window.close();
  }, 2000);
});

// Process answer key file uploads
async function processAnswerKeyFiles() {
  const fileInput = document.getElementById('answerKeyFiles');
  const files = fileInput.files;

  if (!files || files.length === 0) {
    return null;
  }

  const images = [];

  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const base64 = await fileToBase64(file);
    images.push(base64);
  }

  return images;
}

// Convert file to base64
function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// Display answer key files
function displayAnswerKeyList(images) {
  const listElement = document.getElementById('answerKeyList');

  if (!images || images.length === 0) {
    listElement.innerHTML = '';
    return;
  }

  listElement.innerHTML = `<div class="help-text">${images.length} image(s) uploaded</div>`;
}

// Update answer key list when files are selected
document.getElementById('answerKeyFiles').addEventListener('change', async () => {
  const images = await processAnswerKeyFiles();
  displayAnswerKeyList(images);
});

// Update API key status indicator
function updateApiKeyStatus(isConfigured) {
  const indicator = document.getElementById('apiKeyIndicator');
  const status = document.getElementById('apiKeyStatus');

  if (isConfigured) {
    indicator.classList.add('active');
    status.textContent = 'Configured';
  } else {
    indicator.classList.remove('active');
    status.textContent = 'Not configured';
  }
}

// Show status message
function showStatus(message, type) {
  const statusElement = document.getElementById('statusMessage');
  statusElement.textContent = message;
  statusElement.className = `status ${type}`;

  // Auto-hide after 5 seconds
  setTimeout(() => {
    statusElement.className = 'status';
  }, 5000);
}
