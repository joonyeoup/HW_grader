/**
 * Gradescope AI Grader - Background Service Worker
 * Handles OpenAI API calls and grading logic
 */

console.log('Gradescope AI Grader: Background script loaded');

// Listen for messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'gradeSubmission') {
    handleGradingRequest(request.data)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ error: error.message }));
    return true; // Keep channel open for async response
  }
});

/**
 * Main grading handler
 */
async function handleGradingRequest(data) {
  const { submissionData, rubricItems, question, rubricText, answerKeyImages } = data;

  console.log('Grading request:', { question, student: submissionData.studentName });

  // Get API key from storage
  const config = await chrome.storage.sync.get(['apiKey']);
  if (!config.apiKey) {
    throw new Error('API key not configured');
  }

  // Get submission images from the data
  const submissionImages = submissionData.images || [];

  if (submissionImages.length === 0) {
    console.warn('No submission images found - AI will grade based on rubric only');
  } else {
    console.log(`Processing ${submissionImages.length} submission images`);
  }

  // Call OpenAI API
  const gradingResult = await callOpenAI(
    config.apiKey,
    question,
    rubricItems,
    rubricText,
    answerKeyImages,
    submissionImages
  );

  return gradingResult;
}

/**
 * Fetch student's PDF submission
 */
async function fetchSubmissionPDF(pdfUrl) {
  // In mock mode, skip actual fetching
  if (pdfUrl.startsWith('mock://')) {
    console.log('🧪 Mock mode: Skipping PDF fetch');
    return [{
      type: 'mock',
      data: 'mock_data'
    }];
  }

  // Fetch the PDF
  const response = await fetch(pdfUrl);
  if (!response.ok) {
    throw new Error(`Failed to fetch PDF: ${response.statusText}`);
  }

  const blob = await response.blob();

  // Convert PDF to images (this is simplified - in production you'd need a PDF.js integration)
  // For now, we'll convert the PDF blob to base64 and pass to OpenAI
  const base64 = await blobToBase64(blob);

  return [{
    type: 'pdf',
    data: base64
  }];
}

/**
 * Convert blob to base64
 */
function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

/**
 * Call OpenAI API to grade submission
 */
async function callOpenAI(apiKey, question, rubricItems, rubricText, answerKeyImages, submissionImages) {
  // Build the prompt
  const prompt = buildGradingPrompt(question, rubricItems, rubricText);

  // Build messages array
  const messages = [
    {
      role: 'system',
      content: `You are an expert grading assistant. Your job is to grade student homework based on a rubric.

IMPORTANT: Your response must be a JSON object with this exact structure:
{
  "rubricItemIndex": <number>,
  "reasoning": "<explanation>"
}

The rubricItemIndex must be the array index (0-based) of the rubric item that best matches the student's work.`
    },
    {
      role: 'user',
      content: [
        {
          type: 'text',
          text: prompt
        },
        // Add answer key images if provided
        ...(answerKeyImages || []).map(img => ({
          type: 'image_url',
          image_url: {
            url: `data:image/png;base64,${img}`
          }
        })),
        // Add student submission images
        ...(submissionImages || []).map(img => ({
          type: 'image_url',
          image_url: {
            url: typeof img === 'string'
              ? `data:image/png;base64,${img}`
              : `data:image/png;base64,${img.data || img}`
          }
        }))
      ]
    }
  ];

  // ============================================================================
  // TESTING MODE: Mock API Response (No API calls, no cost)
  // ============================================================================
  // Uncomment this section for testing without making real API calls:
  /*
  console.log('🧪 MOCK MODE: Returning first rubric item (no API call)');
  return {
    rubricItemIndex: 0,
    reasoning: "Mock testing - always selects first rubric item",
    rawResponse: "{}"
  };
  */

  // ============================================================================
  // PRODUCTION MODE: Real OpenAI API Calls
  // ============================================================================
  console.log('🤖 Calling OpenAI API for grading...');

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: 'gpt-4o',
      messages: messages,
      max_tokens: 1000,
      temperature: 0.3,
      response_format: { type: 'json_object' }
    })
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(`OpenAI API error: ${error.error?.message || response.statusText}`);
  }

  const result = await response.json();
  const content = result.choices[0].message.content;

  console.log('OpenAI response:', content);

  // Parse JSON response
  let parsedResult;
  try {
    parsedResult = JSON.parse(content);
  } catch (e) {
    console.error('Failed to parse OpenAI response:', content);
    throw new Error('Invalid response from AI');
  }

  console.log('Parsed result:', parsedResult);

  return {
    rubricItemIndex: parsedResult.rubricItemIndex,
    reasoning: parsedResult.reasoning,
    rawResponse: content
  };
}

/**
 * Build grading prompt
 */
function buildGradingPrompt(question, rubricItems, rubricText) {
  let prompt = `You are grading a student's homework submission for: ${question}\n\n`;

  // Add rubric context if provided
  if (rubricText) {
    prompt += `=== RUBRIC CONTEXT ===\n${rubricText}\n\n`;
  }

  // Add rubric items
  prompt += `=== AVAILABLE GRADING OPTIONS ===\n`;
  prompt += `Select ONE rubric item by its index (0-based):\n\n`;
  rubricItems.forEach((item, index) => {
    prompt += `Index ${index}: "${item.label}" (${item.points} points)\n`;
  });

  prompt += `\n=== YOUR TASK ===\n`;
  prompt += `1. Carefully review the student's work in the submission images below\n`;
  prompt += `2. If answer key images are provided, compare the student's work against them\n`;
  prompt += `3. Evaluate the quality and correctness of the student's submission\n`;
  prompt += `4. Select the rubric item (by index) that best matches the student's performance\n`;
  prompt += `5. Provide clear reasoning for your decision\n\n`;

  prompt += `=== RESPONSE FORMAT ===\n`;
  prompt += `Return ONLY a JSON object with this exact structure:\n`;
  prompt += `{\n`;
  prompt += `  "rubricItemIndex": <number from 0 to ${rubricItems.length - 1}>,\n`;
  prompt += `  "reasoning": "<your explanation>"\n`;
  prompt += `}\n\n`;

  prompt += `IMPORTANT: \n`;
  prompt += `- rubricItemIndex must be a number (0 = first item, 1 = second item, etc.)\n`;
  prompt += `- Be fair but rigorous in your grading\n`;
  prompt += `- Consider partial credit when appropriate\n\n`;

  prompt += `=== STUDENT SUBMISSION ===\n`;
  prompt += `The student's work is shown in the images below:\n`;

  return prompt;
}

// Handle extension installation
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    console.log('Gradescope AI Grader installed');
    // Open options page on first install
    chrome.tabs.create({
      url: chrome.runtime.getURL('popup.html')
    });
  }
});
